from .snk import SallenAndKey

class Filters:
    def __init__(self):
        self.snk = SallenAndKey()

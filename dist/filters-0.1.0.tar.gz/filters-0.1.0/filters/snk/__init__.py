from .tchebychev import Tchebychev

class SallenAndKey:
    def __init__(self):
        self.tchebychev = Tchebychev()

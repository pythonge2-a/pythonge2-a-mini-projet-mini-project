class Choice:
    def __init__(self):
        print("Choice initialized")
